This package permanently bricks your device.

Please do not install it. It is nothing but a proof of concept.